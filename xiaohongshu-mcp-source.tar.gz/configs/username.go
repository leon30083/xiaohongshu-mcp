package configs

const (
	Username = "xiaohongshu-mcp"
)
